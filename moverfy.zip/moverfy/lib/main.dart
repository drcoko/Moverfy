import 'package:flutter/material.dart';
void main() => runApp(const MoverfyApp());
class MoverfyApp extends StatelessWidget {
  const MoverfyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(home: Scaffold(body: Center(child: Text('Moverfy'))));
  }
}
